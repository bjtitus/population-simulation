import grid.*;

/**
 * <<Class summary>>
 *
 * @author Brandon Titus &lt;&gt;
 * @version $Rev$
 */
public class PopTester{
	
    public static void main(String[] args){
		Grid<Organism> gr = new BoundedGrid<Organism>(40, 60);
        Plant fern = new Plant(15.0, 30.0, 5.0, 20.0, gr);
		System.out.println(fern);
		Mammal leopard = new Mammal(40.0, 100.0, true, 20.0, 10.0, 17.0, gr);
		System.out.println(leopard);
		
		for(int i=0; i<30; i++)
		{
			if(fern.getLocation() != null)
			{
				fern.act();
			}
			if(leopard.getLocation() != null)
			{
				leopard.act();
			}
			System.out.println(fern);
			System.out.println(leopard);
    	}
	}
}
