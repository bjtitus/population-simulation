import grid.*;

/**
 * <<Class summary>>
 *
 * @author Brandon Titus &lt;&gt;
 * @version $Rev$
 */
public class Plant extends Organism {
    
    public Plant(double size, double life, double minTemp, double maxTemp, Grid<Organism> gr) {
		setSize(size);
		setLife(life);
		setTemp(minTemp, maxTemp);
		Location loc = new Location(15, 5);
		putSelfInGrid(gr, loc);
    }

	/**
	 * Checks to see if the plant is dead yet (<code>life</code> is 0) and removes from the grid if it is.
	 */
	public void act()
	{
		if(getLife() == 0)
		{
			removeSelfFromGrid();
		}
		else
		{
			setLife(getLife()-1);
		}
	}

}
