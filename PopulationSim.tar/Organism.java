import grid.*;

/**
 * <<Class summary>>
 *
 * @author Brandon Titus &lt;&gt;
 * @version $Rev$
 */

public class Organism {
	
	private Grid<Organism> grid;
	private Location location;
	private int direction;
	private double speed, size, life, maxTemp, minTemp;
	private boolean meat;
   
    public void Organism(double speed, double size, boolean meat, double life) {
       	location = null;
		direction = Location.NORTH;
		grid = null;
    }

	//Accessors
	
	/**
	 * Gets the speed of this organism.
	 * @return the speed of this organism.
	 */
	public double getSpeed()
	{
		return speed;
	}
	/**
	 * Gets the size of this organism.
	 * @return the size of this organism.
	 */
	public double getSize()
	{
		return size;
	}
	/**
	 * Gets the boolean value of <code>meat</code> for this organism.
	 * @return the boolean value of <code>meat</code>.
	 */
	public boolean eatsMeat()
	{
		return meat;
	}
	/**
	 * Gets the current life value of this organism.
	 * @return the life value for this organism.
	 */
	public double getLife()
	{
		return life;
	}
	/**
	 * Gets the current direction of this organism.
	 * @return the direction of this organism, an angle between 0 and 359 degrees.
	 */
	public int getDirection()
	{
		return direction;
	}
	/**
	 * Gets the grid of this organism.
	 * @return the grid of this organism.
	 */
	public Grid<Organism> getGrid()
	{
		return grid;
	}
	/**
	 * Gets the current location of this organism.
	 * @return the current location of this organism.
	 */
	public Location getLocation()
	{
		return location;
	}
	
	//Mutators
	
	/**
	 * Sets the speed of the organism.
	 * @param speed the speed value for this organism.
	 */
	public void setSpeed(double speed)
	{
		this.speed = speed;
	}
	/**
	 * Sets the size of the organism.
	 * @param size the size of the organism.
	 */
	public void setSize(double size)
	{
		this.size = size;
	}
	/**
	 * Sets whether this organism can eat meat.
	 * @param meat the boolean value for whether the organism can eat meat.
	 */
	public void eatsMeat(boolean meat)
	{
		this.meat = meat;
	}
	/**
	 * Sets the life value of this organism.
	 * @param life the new life value.
	 */
	public void setLife(double life)
	{
		this.life = life;
	}
	/**
	 * Sets the maximum and minimum temperature values of this organism.
	 * @param minTemp the minimum temperature value.
	 * @param maxTemp the maximum temperature value.
	 */
	public void setTemp(double minTemp, double maxTemp)
	{
		this.minTemp = minTemp;
		this.maxTemp = maxTemp;
	}
	/**
	 * Sets the current direction of this organism.
	 * @param newDirection the new direction. The direction of this organism is set
	 * to the angle between 0 and 359 degrees that is equivalent to
	 * <code>newDirection</code>.
	 */
	public void setDirection(int newDirection)
    {
        direction = newDirection % Location.FULL_CIRCLE;
        if (direction < 0)
            direction += Location.FULL_CIRCLE;
    }

	/**
	 * Puts this organism into a grid. If there is another organism at the given
	 * location, it is removed. <br />
	 * Precondition: (1) This organism is not contained in a grid (2) <code>loc</code>
	 * is valid in <code>gr</code>
	 * @param gr the grid into which this organism should be placed
	 * @param loc the location into which the organism shold be placed
	 */
	public void putSelfInGrid(Grid<Organism> gr, Location loc)
    {
        if (grid != null)
            throw new IllegalStateException(
                    "This organism is already contained in a grid.");

        Organism organism = gr.get(loc);
        if (organism != null)
            organism.removeSelfFromGrid();
        gr.put(loc, this);
        grid = gr;
        location = loc;
    }

	/**
	 * Moves this organism to a new location. If there's another organism at
	 * the new location, that organism is removed. <br />
	 * Precondition: (1) This organism is contained in a grid
	 * (2) <code>newLocation</code> is valid in the grid of this organism
	 * @param newLocation the new location
	 */
	public void moveTo(Location newLocation)
    {
        if (grid == null)
            throw new IllegalStateException("This organism is not in a grid.");
        if (grid.get(location) != this)
            throw new IllegalStateException(
                    "The grid contains a different organism at location "
                            + location + ".");
        if (!grid.isValid(newLocation))
            throw new IllegalArgumentException("Location " + newLocation
                    + " is not valid.");

        if (newLocation.equals(location))
            return;
        grid.remove(location);
        Organism other = grid.get(newLocation);
        if (other != null)
            other.removeSelfFromGrid();
        location = newLocation;
        grid.put(location, this);
    }

	/**
	 * Removes this organism from its grid. <br />
	 * Precondition: This actor is contained in a grid
	 */
	public void removeSelfFromGrid()
    {
        if (grid == null)
            throw new IllegalStateException(
                    "This organism is not contained in a grid.");
        if (grid.get(location) != this)
            throw new IllegalStateException(
                    "The grid contains a different organism at location "
                            + location + ".");

        grid.remove(location);
        grid = null;
        location = null;
    }
	
	/**
	* Creates a string that describes an actor
	* @return String with the location, direction, min and max temps, size, meat value, life, and speed of this organism.
	*/
	public String toString()
	{
		return getClass().getName() + "[location=" + location + ",direction="
                + direction + ",temps=" + minTemp + "," + maxTemp + ",size=" + size +
 				",meat=" + meat + ",life=" + life + ",speed=" + speed + "]";
	}
}
