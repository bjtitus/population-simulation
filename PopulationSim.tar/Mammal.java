import grid.*;
import java.util.*;

/**
 * <<Class summary>>
 *
 * @author Brandon Titus &lt;&gt;
 * @version $Rev$
 */
public class Mammal extends Organism{
    
    public Mammal(double size, double speed, boolean meat, double life, double minTemp, double maxTemp, Grid<Organism> gr) {
        setSize(size);
		setSpeed(speed);
		eatsMeat(meat);
		setLife(life);
		setTemp(minTemp, maxTemp);
		Location loc = new Location(20, 5);
		putSelfInGrid(gr, loc);
    }

	/**
	 * Checks to see if mammal is dead yet (<code>life</code> is 0) and removes from the grid if it is.
	 * If it isn't, the mammal is moved and <code>life</code> is decreased by 1.
	 */
	public void act()
	{
		if(getLife() == 0)
		{
			removeSelfFromGrid();
		}
		else
		{
			move();
			setLife(getLife()-1);
		}
	}
	
	/**
	 * Looks at surrounding organisms and removes them from the grid if this mammal can eat them.
	 * @param organisms the list of organisms surrounding the mammal.
	*/
	public void processOrganisms(ArrayList<Organism> organisms)
    {
        for (Organism a : organisms)
        {
            if (this.getSize() > a.getSize())
			{
				if(this.eatsMeat() && (a instanceof Mammal))
				{ a.removeSelfFromGrid(); }
				if(!this.eatsMeat() && (a instanceof Plant))
				{ a.removeSelfFromGrid(); }
			}
        }
    }
	
	/**
	 * Moves the mammal down by one.
	 */
	public void move()
    {
        Grid<Organism> gr = getGrid();
        if (gr == null)
            return;
        Location loc = getLocation();
        Location next = loc.getAdjacentLocation(getDirection());
        if (gr.isValid(next))
            moveTo(next);
        else
            removeSelfFromGrid();
    }
}
